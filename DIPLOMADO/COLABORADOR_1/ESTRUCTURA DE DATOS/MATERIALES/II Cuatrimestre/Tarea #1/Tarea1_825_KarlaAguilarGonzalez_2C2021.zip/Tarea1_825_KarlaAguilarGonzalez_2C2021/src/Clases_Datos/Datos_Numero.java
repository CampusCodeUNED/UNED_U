package Clases_Datos;

/**
 *
 * @author Karla Bricelda Aguilar González
 */

public class Datos_Numero {
//Declaración del atributo de la clase

    private int Numero;

    //Constructor con parámetros
    public Datos_Numero(int Numero) {
        this.Numero = Numero;
    }

    //Get and set del atributo de la clase
    public int getNumero() {
        return Numero;
    }

    public void setNumero(int Numero) {
        this.Numero = Numero;
    }

}
